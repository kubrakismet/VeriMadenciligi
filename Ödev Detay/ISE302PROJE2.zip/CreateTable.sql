CREATE TABLE [dbo].[FirmaData](
	[FirmaKod] [tinyint] NULL,
	[Sehir] [nvarchar](10) NULL,
	[KurulusTarihi] [smalldatetime] NULL,
	[Kredibilite] [tinyint] NULL,
	[Iskonto] [tinyint] NULL
)